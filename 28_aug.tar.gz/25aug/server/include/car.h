#ifndef car 
#define car
#include "masterheaders.h"
class car : public vehicle
{
protected:
	string airBags,ABS,seats,gpsFacility;
};
#endif 
