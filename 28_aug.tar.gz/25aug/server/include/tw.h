#ifndef tw_
#define tw_

#include "masterheaders.h"
#include "vehicle_class.h"

class tw : public vehicle_class
{

};

#endif 
