#ifndef car_gearls 
#define car_gearls
#include "masterheaders.h"
class car_gearless : public car
{
protected:
	string cruiseMode;
};

#endif 
