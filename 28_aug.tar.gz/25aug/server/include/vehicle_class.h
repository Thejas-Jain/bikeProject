#ifndef vehicle_
#define vehicle_
#include "masterheaders.h"

typedef map<string, string> specs;
class vehicle_class
{
protected:
	specs gaadi;
};

#endif
