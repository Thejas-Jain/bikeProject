#ifndef tw_gearless
#define tw_gearless 

#include "masterheaders.h"
class tw_gearless : public tw
{
protected:
	string dikkiSize;
};

#endif 

