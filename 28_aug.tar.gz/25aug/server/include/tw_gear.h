#ifndef tw_gear_ 
#define tw_gear_

#include "tw.h"
#include "masterheaders.h"

class tw_gear : public tw
{
public:
        tw_gear(specs);
        void show_details(void);
};
#endif 
