#ifndef car_gear  
#define car_gear
#include "masterheaders.h"
using namespace std;
class car_gear : public car
{
protected:
	string numGears;
};

#endif 
